#include <iostream>
#include "modelztext.h"
using namespace std;

int main()
{
    ModelZText a("helloworld");

    a.TextDeleteLine(5);
    return 0;
}
