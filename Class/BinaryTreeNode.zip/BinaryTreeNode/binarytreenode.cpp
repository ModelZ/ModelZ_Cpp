#include "binarytreenode.h"

BinaryTreeNode::BinaryTreeNode(int element, BinaryTreeNode *left, BinaryTreeNode *right)
    : element(element),left(left),right(right)
{

}
