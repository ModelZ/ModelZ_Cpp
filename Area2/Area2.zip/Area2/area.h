#ifndef AREA_H
#define AREA_H


class Area
{
protected:
    float area;
public:
    Area();
    void set_area(float area);
    float get_area();
};

#endif // AREA_H
