#ifndef CIRCLE2_H
#define CIRCLE2_H
#include "circle.h"

class Circle2 : public Circle
{
public:
    Circle2();
    bool set_redius(float radius);
};

#endif // CIRCLE2_H
