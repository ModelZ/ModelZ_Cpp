#include "area.h"

Area::Area() :area(0)
{}

void Area::set_area(float area)
{
    this->area = area;
}

float Area::get_area()
{
    return area;
}

